#!/usr/bin/env python3
import argparse
import subprocess
import sys

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yml")
    args = ap.parse_args()
    subprocess.check_call([sys.executable, "scripts/purdue_refresh_from_web.py", "--config", args.config])

if __name__ == "__main__":
    main()
